CRISP CUTE - Free Sampler
=========================

A soft, cute UI kit for cozy games (farming, life-sim, cafe, pet and cozy puzzle games): 130 pieces in each of
6 pastel themes (Strawberry Milk, Matcha, Honey, Lavender, Cloud, Peach), plus 138 colour icons.
PNG 1x + 2x and SVG, 9-slice borders listed, Godot 4 themes, and the free Fredoka font.

GET THE FULL PACK
  This free sampler has 54 images: 34 pieces from the Strawberry Milk theme and 20 icons.
  The full pack has 918 images (2754 files): all 6 themes, all 138 icons and the Godot 4 themes.
  GET THE FULL PACK: https://anipixels.itch.io/crisp-cute
  Or get every Crisp pack in one bundle: https://itch.io/s/203391/crisp-everything-bundle

WHAT IS IN THE ZIP
  PNG/1x/         every piece at base size (made for roughly 960 x 540 to 1280 x 720 layouts)
  PNG/2x/         the same pieces at double size (1080p and up, phones, HiDPI)
  SVG/            the same pieces as vector files
  sheets.json     every piece: file paths, sizes, 9-slice borders, content padding, tiling, notes
  fonts/          Fredoka (SIL Open Font License 1.1, see fonts/OFL.txt)

FOLDERS INSIDE PNG AND SVG
  strawberry, icons
  (the full pack has 6 themes and 138 icons)

THE THEMES
  strawberry  Strawberry Milk - pink with mint-green secondary buttons, cream paper
  matcha      Matcha - soft green with toasted-tea brown, warm off-white paper
  honey       Honey - golden yellow with apricot, honey-cream paper
  lavender    Lavender - lilac with candy pink, cool white paper
  cloud       Cloud - sky blue with sunshine yellow, pure white paper
  peach       Peach - peach with sea-glass teal, warm cream paper
  Each theme also has a backdrop colour (palette.json: bg, bg2) that the screenshots use.

TEXT AND CONTRAST
  Body text: use the theme's 'text' colour on paper (contrast 7:1 or better in every theme; 'muted' is 3:1 or better).
  Labels on buttons, ribbons, title bars and name tags: white with an outline in the art's line colour
  (accent.line, secondary.line). Godot's themes do this with font outlines; the web demo with text-shadow.
  If you prefer no outline, use the dark 'ink' colour of that ramp instead (4.5:1 or better on the face colour).
  palette.json lists the measured contrast ratios for every theme.

9-SLICE PIECES
  73 of the 130 themed pieces are 9-slice (or 3-slice) frames: buttons, panels, windows, bars, tabs, inputs, bubbles.
  Their borders are in sheets.json (slice_1x / slice_2x, in pixels from each edge). Stretch the middle, keep the corners.
  Every heart, glint and ear sits inside the borders.
  4 pieces have repeating edges (stitches, cloud bumps, awning stripes). Their middles hold a whole number of
  repeats: tile them (Godot axis stretch Tile Fit - already set in the themes; CSS border-image 'round'; Unity Tiled)
  to keep the pattern even. Stretching works too, the stitches just get a little longer.
  A note of 'fixed height' means the piece only stretches sideways.
  Button states share one canvas size; the pressed face sits lower, with a thinner bottom shade.

HOW A FEW PIECES FIT TOGETHER
  Bars      bar_track + a bar_fill_* at the same position (fills carry 4 px of padding). Put a bar_cap_* over the
            left end. bar_track_thin + bar_fill_thin are the slim version.
  Dialogue  dialog_box with name_tag overlapping its top-left edge and dialog_continue bouncing bottom-right;
            avatar_frame (transparent middle) to its left.
  Hotbar    hotbar_tray holding hotbar_slot / hotbar_slot_active (56 px); slot_count_badge in a slot corner.
  HUD       day_plate takes a weather icon in its round sky window; coin_plate a coin, clock_plate a clock or sun.
  Calendar  calendar_tile, _today, _event (heart), _past: 48 x 52, day number in the white area.
  Tabs      tab_* are open at the bottom; overlap tab_panel by 3 px.

FONTS
  The pack includes Fredoka (fonts/Fredoka.ttf), a free rounded font by The Fredoka Project Authors, unchanged,
  under the SIL Open Font License 1.1 (fonts/OFL.txt). It is a variable font: weight 300-700. The demo, the
  screenshots and the Godot themes use it at weight 600. You can swap in any other font; no piece has text baked in.

THEMED PIECES (130 per theme)
  In this sampler:
    button_medium_normal
    button_medium_hover
    button_medium_pressed
    button_medium_disabled
    button_round_normal
    button_round_pressed
    button_close_normal
    panel
    panel_cloud
    panel_inset
    window_ears
    dialog_box
    name_tag
    dialog_continue
    tooltip
    checkbox_off
    checkbox_on
    toggle_off
    toggle_on
    slider_track
    slider_fill
    slider_knob_normal
    bar_track
    bar_fill_health
    bar_cap_heart
    slot
    slot_selected
    hotbar_slot
    coin_plate
    ribbon
    heart_full
    heart_empty
    star_full
    star_empty
  Icons: heart, star, coin, settings, close, check, play, pause, home, sprout, watering_can, carrot, strawberry, flower, cat, chick, egg, cake, tea, sun

See LICENSE.txt for usage terms (and fonts/OFL.txt for the font).
