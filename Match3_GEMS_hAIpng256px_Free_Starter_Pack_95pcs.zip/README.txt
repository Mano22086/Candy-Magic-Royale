Match3 GEMS hAIpng256px - Free Starter Pack (95 pcs)
=====================================================

[ASSET SPECS]
- Total files: 95
- Format: PNG (.png)
- Transparency: Yes (Transparent background)
- Item resolution: 256x256 px
- Background resolution: 720x1200 px
- Content type: AI-Generated Assets

[FOLDER STRUCTURE (AI-Generated images)]
- 01_square to 09_artefact: Core pieces in 6 colors - Red, Yellow, Green, Blue, White, Black (6 files each: 1_red.png to 6_black.png).
- 10_power: Special abilities / power-ups (9 files: 1.png to 9.png).
- 11_blocker: Obstacles, ice, cages, stones (9 files: 1.png to 9.png).
- 12_tile: Board cells / grid tiles (9 files: 1.png to 9.png).
- 13_ui: HUD / button icons (9 files: 1.png to 9.png).
- 14_bgd: Portrait game backgrounds (5 files: 1.png to 5.png).

[LICENSE (Custom Commercial License)]
- Free for personal and commercial projects.
- AI-Generated images can be modified and used freely.
- Asset pack compilation: Redistribution or reselling is prohibited.
